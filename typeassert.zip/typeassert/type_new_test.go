package typeassert

import (
	"testing"
)

func TestNewType(t *testing.T) {

}

