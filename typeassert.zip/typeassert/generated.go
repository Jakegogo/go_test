package typeassert


type S1 struct {
	I int
}
